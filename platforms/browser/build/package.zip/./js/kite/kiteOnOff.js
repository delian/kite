/**
 * Created by delian on 9/17/15.
 */
define(function(require, module, exports) {
    var status = {
        on: false
    };
    return status;
});
